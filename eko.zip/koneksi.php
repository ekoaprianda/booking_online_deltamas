<?php
$servername = "156.67.213.118";
$username = "u5142707_thamrin_root";
$password = "Thamrin456852";
$dbname = "u5142707_barang_it";

$con = mysqli_connect($servername, $username, $password, $dbname);
  if($con){
   echo "";
    }else{
        echo "koneksi internet gagal";
    }
?>