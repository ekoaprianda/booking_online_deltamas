
<?php

session_start();$cabang=$_SESSION['cabang'];
if ($_SESSION['isLoggedIn']!=1) {
echo("<script language=\"javascript\">
	window.alert(\"Silahkan Login\");
	window.location.href=\"../login\";
	</script>");}
	$LAB_NUM = $_GET['LAB_NUM'];

//CEK OTORITAS HALAMAN	
$USER_ID =$_SESSION['USER_ID'];
include "..\koneksi\\$cabang\konekmachine.php";
$module_id='lihathasillab';
$query_cek_otoritas="SELECT MODULE_ID,TAMPIL from NEW_MODULE_USER where USER_ID='$USER_ID' and MODULE_ID='$module_id'";
$execute=sqlsrv_query($conn,$query_cek_otoritas) or die(sqlsrv_errors()); 
$cekotoritas=sqlsrv_fetch_array($execute);
if($cekotoritas['TAMPIL']==1):;
	else:echo "<script language=javascript>window.alert(\"Anda Tidak Punya Otoritas\")</script>";
		 echo "<script language=javascript>var prev=document.referrer; window.location.href=prev</script>"; endif;

require('../REPORT/fpdf.php');
class PDF extends FPDF
{
// Page header
function Header()
{	$this->SetY(+51);
$cabang=$_SESSION['cabang'];
require "..\KONEKSI\\$cabang\konekorder.php";
$LAB_NUM = $_GET['LAB_NUM'];
$sql19="SELECT LAB_NUM, DATE,PATIENT_NAME, PATIENT_ADDRESS, PATIENT_POSITION, PATIENT_AGE, PARTNER_NAME, PATIENT_SEX, PATIENT_DATE_BIRTH,DOCTOR_NAME FROM [ORDER] where lab_num='$LAB_NUM'";
$query19=sqlsrv_query($conn,$sql19) or die(sqlsrv_errors());$data19=sqlsrv_fetch_array($query19);
$ttl= date("d-m-Y",strtotime($data19['PATIENT_DATE_BIRTH']));
$tglperiksa= date("d-m-Y H:i",strtotime($data19['DATE']));

$this->SetFont('Arial','B',9.5); $this->Cell(33,5.7,'NAMA PASIEN',0,0,'L'); 		$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',9.5); $this->Cell(69,5,$data19['PATIENT_NAME'],0,0,'L');				$this->SetFont('Arial','B',9.5); $this->Cell(22,5,'KODE LAB',0,0,'L');		$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',9.5); $this->Cell(35,5,$data19['LAB_NUM'],0,1,'L');
$this->SetFont('Arial','B',9.5); $this->Cell(33,5.7,'TGL. LAHIR / UMUR',0,0,'L'); 	$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',9.5); $this->Cell(69,5,$ttl .' / '. $data19['PATIENT_AGE'],0,0,'L');	$this->SetFont('Arial','B',9.5); $this->Cell(22,5,'TANGGAL',0,0,'L');		$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',9.5); $this->Cell(35,5,$tglperiksa,0,1,'L');
$lab_num_substring= substr($LAB_NUM,0,1);
if($lab_num_substring!=8):
$this->SetFont('Arial','B',9.5); $this->Cell(33,5.7,'JENIS KELAMIN',0,0,'L'); 		$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',9.5); $this->Cell(69,5,$data19['PATIENT_SEX'],0,0,'L');					$this->SetFont('Arial','B',9.5); $this->Cell(22,5,'DOKTER',0,0,'L');		$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',9.5); $this->Cell(35,5,$data19['DOCTOR_NAME'],0,1,'L');
$this->SetFont('Arial','B',9.5); $this->Cell(33,5.7,'ALAMAT',0,0,'L'); 				$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',9.5); $this->MultiCell(69,4,$data19['PATIENT_ADDRESS'],0,'L',false);				

elseif($lab_num_substring==8):
$this->SetFont('Arial','B',9.5); $this->Cell(33,5.7,'JENIS KELAMIN',0,0,'L'); 		$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',9.5); $this->Cell(69,5,$data19['PATIENT_SEX'],0,0,'L');					$this->SetFont('Arial','B',9.5); $this->Cell(22,5,'PENGIRIM',0,0,'L');		$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',9.5); $this->MultiCell(55,5,$data19['PARTNER_NAME'],0,'L',false);
$this->SetFont('Arial','B',9.5); $this->Cell(33,5.7,'JABATAN',0,0,'L'); 			$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',9.5); $this->Cell(69,4,$data19['PATIENT_POSITION'],0,0,'L');	$this->SetFont('Arial','B',9.5); $this->Cell(22,5,'DOKTER',0,0,'L');				$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',9.5); $this->Cell(35,5,$data19['DOCTOR_NAME'],0,1,'L');			
endif;

$this->Ln(2);
	
// Garis Bawah Double
$this->SetFont('Arial','B',9.5);
$this->SetLineWidth(0.4);
$this->Cell(52,8,'NAMA PEMERIKSAAN','TB',0,'L');$this->Cell(25,8,'HASIL','TB',0,'C');$this->Cell(35,8,'SATUAN','TB',0,'C');$this->Cell(39.5,8,'NILAI RUJUKAN','TB',0,'C');$this->Cell(39,8,'     METODE','TB',1,'C');
$this->Ln(1);
    

}

// Page footer
function Footer()
{
	$cabang=$_SESSION['cabang'];
require "..\KONEKSI\\$cabang\konekresult.php";
$LAB_NUM = $_GET['LAB_NUM'];
$USER_ID =$_SESSION['USER_ID'];

	if(!empty($LAB_NUM)){
	$sql="SELECT LAB_NUM,DOCTOR_ID_LAB,DOCTOR_NAME_LAB,PRINTED_BY,PRINTED_TIME,USER_ID,TIME,VALIDATED_BY,VALIDATED_TIME FROM RESULT_LAB where lab_num='$LAB_NUM'";
    $query=sqlsrv_query($conn,$sql);$data12=sqlsrv_fetch_array($query);}
	
	if(empty($data12['LAB_NUM'])){
		goto b;}else{ goto d;}
		
	b:
	$sql="SELECT LAB_NUM,DOCTOR_ID_LAB,DOCTOR_NAME_LAB,PRINTED_BY,PRINTED_TIME,USER_ID,TIME,VALIDATED_BY,VALIDATED_TIME FROM RESULT_LAB_2 where lab_num='$LAB_NUM'";
    $query=sqlsrv_query($conn,$sql);$data12=sqlsrv_fetch_array($query);
	
	if(empty($data12['LAB_NUM'])){
		goto c;}else{goto d;}
		
	c:
	$sql="SELECT LAB_NUM,DOCTOR_NAME_LAB,DOCTOR_ID_LAB,PRINTED_BY,PRINTED_TIME,USER_ID,TIME,VALIDATED_BY,VALIDATED_TIME FROM RESULT_LAB_3 where lab_num='$LAB_NUM'";
    $query=sqlsrv_query($conn,$sql);$data12=sqlsrv_fetch_array($query);
	 
	 if(empty($data['LAB_NUM'])){
		goto y;}else{goto d;}
		
	y:
	$sql="SELECT LAB_NUM,DOCTOR_NAME_LAB,DOCTOR_ID_LAB,PRINTED_BY,PRINTED_TIME,USER_ID,TIME,VALIDATED_BY,VALIDATED_TIME FROM lab_data_result_old.dbo.RESULT_LAB_3 where lab_num='$LAB_NUM'";
    $query=sqlsrv_query($conn,$sql);$data12=sqlsrv_fetch_array($query);

	d:
	$validated_by=$data12['VALIDATED_BY'];
	$DOCTOR_ID_LAB=$data12['DOCTOR_ID_LAB'];
	$DOCTOR_NAME_LAB=$data12['DOCTOR_NAME_LAB'];
	$wktsimpan= date("d-m-Y H:i",strtotime($data12['TIME']));
	$wktvalidasi= date("d-m-Y H:i",strtotime($data12['VALIDATED_TIME']));
	date_default_timezone_set('Asia/Jakarta');
	$wktcetak= date("d-m-Y H:i");
	
    // Posisi 6 cm dari bawah
    $this->SetY(-60);

    
    // Arial italic 8
    $this->SetFont('Arial','',8);
	$this->Cell(190,1,'','T',1,'L');
	$this->SetFont('Arial','',8); $this->Cell(21,5,'Divalidasi Oleh',0,0,'L'); 	$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',8); $this->Cell(114,5,$validated_by,0,0,'L');								$this->SetFont('Arial','',9.5); $this->Cell(25,5,'Salam Sejawat,',0,1,'L');	
	$this->Ln(-0.5);
	$this->SetFont('Arial','',8); $this->Cell(21,5,'Dicetak Oleh',0,0,'L'); 		$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',8); $this->Cell(114.5,5,$USER_ID,0,1,'L');								//$this->Image('../IMAGE/DOKTER/'.$DOCTOR_ID_LAB.'.png', 142,243, 40,20);
	$this->Ln(-0.5);
	$this->SetFont('Arial','',8); $this->Cell(21,5,'Tanggal Cetak',0,0,'L'); 		$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',8); $this->Cell(74,5,$wktcetak,0,1,'L');									
	$this->Ln(-0.5);
	$this->SetFont('Arial','',8); $this->Cell(21,5,'Halaman',0,0,'L'); 			$this->Cell(3,5,':',0,0,'L'); $this->SetFont('Arial','',8); $this->Cell(74,5,$this->PageNo().' / {nb}',0,1,'L');		

	$this->SetY(-33);
	$this->SetX(+136);
	$this->SetFont('Arial','B',9.5); $this->Cell(50,5,$DOCTOR_NAME_LAB,0,1,'C'); 
 
}
}

//Membuat file PDF
$pdf = new PDF('P','mm','A4');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',9.5);
$pdf->SetAutoPageBreak(true,58);
$pdf->SetTitle('LAB-'.$LAB_NUM);


//Mencetak kalimat 

$cabang=$_SESSION['cabang'];
require "..\KONEKSI\\$cabang\konekresult.php";
$LAB_NUM = $_GET['LAB_NUM'];
$tabel ='RESULT_LAB_DETAIL'; 


	$sql1="SELECT LAB_NUM FROM $tabel where lab_num='$LAB_NUM'";
    $query1=sqlsrv_query($conn,$sql1) or die(sqlsrv_errors());$data1=sqlsrv_fetch_array($query1);
		
	if(empty($data1['LAB_NUM'])){
		goto b;}else{ goto d;}
		
	b:$tabel ='RESULT_LAB_DETAIL_2';  
	$sql1="SELECT LAB_NUM FROM $tabel where lab_num='$LAB_NUM'";
    $query1=sqlsrv_query($conn,$sql1) or die(sqlsrv_errors());$data1=sqlsrv_fetch_array($query1);
	
	if(empty($data1['LAB_NUM'])){
		goto c;}else{goto d;}
		
	c:$tabel ='RESULT_LAB_DETAIL_3';  
	$sql1="SELECT LAB_NUM FROM $tabel where lab_num='$LAB_NUM'";
    $query1=sqlsrv_query($conn,$sql1) or die(sqlsrv_errors());$data1=sqlsrv_fetch_array($query1);
	
	 
	 if(empty($data1['LAB_NUM'])){
		goto y;}else{goto d;}
		
	y:$tabel ='lab_data_result_old.dbo.RESULT_LAB_DETAIL_3';  
	$sql1="SELECT LAB_NUM FROM $tabel where lab_num='$LAB_NUM'";
    $query1=sqlsrv_query($conn,$sql1) or die(sqlsrv_errors());$data1=sqlsrv_fetch_array($query1);

	d:
    $sql="SELECT ITEM_EXAM_ID,DESCRIPTION,RESULT,UNIT,BOLD,NORMAL_VALUE,METHOD FROM $tabel where lab_num='$LAB_NUM' 
	ORDER by ITEM_EXAM_ID,ID_SORT,sort asc";
     $query=sqlsrv_query($conn,$sql) or die(sqlsrv_errors());
	$category_temp='';
	 while($data1=sqlsrv_fetch_array($query)){
		 
		 $ITEM_EXAM_ID=$data1['ITEM_EXAM_ID'];
		 $sql2="select CATEGORY_NAME from lab_sys.dbo.ITEM_EXAM where ITEM_EXAM_ID='$ITEM_EXAM_ID'";
		 $query2=sqlsrv_query($conn,$sql2) or die(sqlsrv_errors());
		 $data2=sqlsrv_fetch_array($query2);
		 if($data2['CATEGORY_NAME']!=$category_temp):
		 $y=$pdf->GetY();//y=173 harus pindah halaman
		 if($y>173):$pdf->AddPage(); else:;endif;
		 $pdf->SetFont('Arial','B',9.5);		 
		 $pdf->Cell(52,5,$data2['CATEGORY_NAME'],0,1,'L');
		 $category_temp=$data2['CATEGORY_NAME'];
		 else:; 
		 endif;
	if($data1['BOLD']=='Y'):
	$pdf->SetFont('Arial','B',9.5);	 
	else:$pdf->SetFont('Arial','',9.5);endif;
	$pdf->Cell(52,5,$data1['DESCRIPTION'],0,0,'L');
	$pdf->Cell(25,5,$data1['RESULT'],0,0,'C');
	$pdf->Cell(30,5,$data1['UNIT'],0,0,'C');
	$x=$pdf->GetX();
	$y=$pdf->GetY();
	$pdf->MultiCell(48,4.5,$data1['NORMAL_VALUE'],0,'C',false);  
	$huruf= $pdf->GetStringWidth($data1['NORMAL_VALUE']);
	
	$pdf->SetXY($x + 48, $y);
	$pdf->SetFont('Arial','',9.5);
	$pdf->MultiCell(39,4.5,$data1['METHOD'],0,'C',false);
	$huruf2= $pdf->GetStringWidth($data1['METHOD']);
	
	if($huruf>=50):
	$pdf->Ln(4.5);elseif($huruf2>=50):$pdf->Ln(4.5);else:$pdf->Ln(0.5);endif;
	 
	 }

//Menutup dokumen dan dikirim ke browser

 sqlsrv_close($conn);
$pdf->Output('LAB-'.$LAB_NUM.'.pdf','I');
?>